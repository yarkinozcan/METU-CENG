#include "hw2.h"
#include "monitor.h"

class MonitorStoreUnit : public Monitor {
    int capacity[3];
    int stock[3];
    int reservedSpace[3];
    int orderLimit;

    Condition buyCond;
    Condition supplyCond[3];

public:
    MonitorStoreUnit()
        : buyCond(this),
          supplyCond{Condition(this), Condition(this), Condition(this)} {}

    void configureStore(int capA, int capB, int capC, int maxOrder) {
        __synchronized__;
        int caps[3] = {capA, capB, capC};
        for (int i = 0; i < 3; ++i) {
            capacity[i] = caps[i];
            stock[i] = caps[i];
            reservedSpace[i] = 0;
        }
        orderLimit = maxOrder;
    }

    void placeOrder(int aCount, int bCount, int cCount) {
        __synchronized__;
        int requested[3] = {aCount, bCount, cCount};
        while (requested[AAA] > stock[AAA] ||
               requested[BBB] > stock[BBB] ||
               requested[CCC] > stock[CCC]) {
            buyCond.wait();
        }

        for (int i = 0; i < 3; ++i) {
            stock[i] -= requested[i];
            supplyCond[i].notifyAll();
        }
    }

    void beginSupply(int itemType, int amount) {
        __synchronized__;
        while (stock[itemType] + reservedSpace[itemType] + amount > capacity[itemType]) {
            supplyCond[itemType].wait();
        }
        reservedSpace[itemType] += amount;
    }

    void finalizeSupply(int itemType, int amount) {
        __synchronized__;
        reservedSpace[itemType] -= amount;
        stock[itemType] += amount;
        buyCond.notifyAll();
    }

    void inspectStock(int outCap[3], int outAvail[3]) {
        __synchronized__;
        for (int i = 0; i < 3; ++i) {
            outCap[i] = capacity[i];
            outAvail[i] = stock[i];
        }
    }
};

static MonitorStoreUnit systemStore;

void initStore(int cA, int cB, int cC, int mO) {
    systemStore.configureStore(cA, cB, cC, mO);
}

void buy(int aA, int aB, int aC) {
    systemStore.placeOrder(aA, aB, aC);
}

void maysupply(int itype, int n) {
    systemStore.beginSupply(itype, n);
}

void supply(int itype, int n) {
    systemStore.finalizeSupply(itype, n);
}

void monitorStore(int c[3], int a[3]) {
    systemStore.inspectStock(c, a);
}