#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <string.h>
#include <fcntl.h>
#include <errno.h>
#include <sys/select.h>
#include <poll.h>
#include "game_structs.h"
#include "print_output.h"


#define PIPE(fd) socketpair(AF_UNIX, SOCK_STREAM, PF_UNIX, fd)

int main() {
    int grid_width, grid_height, streak_size, player_count;
    char** grid;
    int **pipes;
    pid_t *player_pids;
    char *player_symbols;
    char ***player_args;
    int *player_arg_count;
    int filled_count = 0;

    scanf("%d %d %d %d", &grid_width, &grid_height, &streak_size, &player_count); // Take the input

    // Allocate memory for the grid
    grid = (char **)malloc(grid_height * sizeof(char *)); // !!!! Must free this memory at the end
    for (int i = 0; i < grid_height; i++) {
        grid[i] = (char *)malloc(grid_width * sizeof(char));
        for (int j = 0; j < grid_width; j++) {
            grid[i][j] = '.';  // Initialize with '.'
        }
    }


    // Allocate memory for player_symbols
    player_symbols = (char *)malloc(player_count * sizeof(char)); // !!!!! Must free this memory at the end

    player_arg_count = (int *)malloc(player_count * sizeof(int)); // !!!!! Must free this memory at the end

    player_args = (char ***)malloc(player_count * sizeof(char **)); // !!!!! Must free this memory at the end

    player_pids = (pid_t *) malloc(player_count * sizeof(pid_t)); // !!!!! Must free this memory at the end

    pipes = (int **) malloc(player_count * sizeof(int *)); // !!!!! Must free this memory at the end

    for(int i = 0; i < player_count ; i++) {
        pipes[i] = (int *) malloc(2 * sizeof(int));  // !!!!! Must free this memory at the end
    }

    for (int i = 0; i < player_count; i++) {
        scanf(" %c %d", &player_symbols[i], &player_arg_count[i]);  // Note the space before %c
    
        player_args[i] = (char **)malloc((player_arg_count[i] + 2) * sizeof(char *)); // !!!!! Must free this memory at the end
    
        char exec_path[256];
        scanf("%s", exec_path);
        player_args[i][0] = strdup(exec_path);  // Correctly assign the executable
    
        for (int j = 1; j <= player_arg_count[i]; j++) {
            char arg[256];
            scanf("%s", arg);
            player_args[i][j] = strdup(arg);
        }
    
        player_args[i][player_arg_count[i] + 1] = NULL;
    }

    for(int i = 0 ; i < player_count ; i++) {
        if(PIPE(pipes[i])) {
            perror("Error when creating Pipe!");
        }
    }
    
    for (int i = 0; i < player_count; i++) {
        player_pids[i] = fork();
        if (player_pids[i]) {
            // Parent process
            close(pipes[i][0]); // Close the child's read end in the parent
        } else {
            // Child process
            dup2(pipes[i][0], STDIN_FILENO);
            dup2(pipes[i][0], STDOUT_FILENO);

            for(int j = 0 ; j < player_count ; j++) {
                close(pipes[j][1]); // Close the parent's write end in the child
                close(pipes[j][0]); // Close original descriptor after dup2
            }
            

            // Execute player executable with its arguments
            execv(player_args[i][0], player_args[i]);

            perror("Exec failed");
            return -1;
        }   
    }

    int winner_detected = 0;
    int is_grid_full = 0;

    struct pollfd fds[player_count];
    for (int i = 0; i < player_count; i++) {
        fds[i].fd = pipes[i][1];
        fds[i].events = POLLIN;
    }

    while (winner_detected == 0 && is_grid_full == 0) {
        int ready = poll(fds, player_count, 1); // Wait 1ms
        if (ready > 0) {
            for (int i = 0; i < player_count; i++) {
                if (fds[i].revents & POLLIN) {
                    cm msg;
                    if (read(pipes[i][1], &msg, sizeof(msg)) > 0) {
                        cmp client_msg = {player_pids[i], &msg};
                        print_output(&client_msg, NULL, NULL, 0); // Log received message
                        // ---------------
                        if (msg.type == START) {
                            sm result = {RESULT, 0, filled_count};
                            write(pipes[i][1], &result, sizeof(result));
                            smp server_msg = {player_pids[i], &result};
    
                            // Send all filled positions
                            gu grid_updates[filled_count];
                            gd grid_data;
                            int k = 0;
                            for (int y = 0; y < grid_height; y++) {
                                for (int x = 0; x < grid_width; x++) {
                                    if(grid[y][x] != '.') {
                                        grid_data.position.x = x;
                                        grid_data.position.y = y;
                                        grid_data.character = grid[y][x];
                                        write(pipes[i][1], &grid_data, sizeof(grid_data));
                                        grid_updates[k].character = grid[y][x];
                                        grid_updates[k].position.x = x;
                                        grid_updates[k].position.y = y;
                                        k++;
                                    }
                                }
                            }
                            print_output(NULL, &server_msg, grid_updates, filled_count); // Log sent result
                        } else if (msg.type == MARK) {
                            if (msg.position.x >= 0 && msg.position.y >= 0 && msg.position.x < grid_width && msg.position.y < grid_height && grid[msg.position.y][msg.position.x] == '.') {
                                filled_count++;
                                grid[msg.position.y][msg.position.x] = player_symbols[i];
    
                                sm result = {RESULT, 1, filled_count};
                                write(pipes[i][1], &result, sizeof(result));

                                // Send all filled positions
                                gu grid_updates[filled_count];
                                gd grid_data;
                                int k = 0;
                                for (int y = 0; y < grid_height; y++) {
                                    for (int x = 0; x < grid_width; x++) {
                                        if(grid[y][x] != '.') {
                                            grid_data.position.x = x;
                                            grid_data.position.y = y;
                                            grid_data.character = grid[y][x];
                                            write(pipes[i][1], &grid_data, sizeof(grid_data));
                                            grid_updates[k].character = grid[y][x];
                                            grid_updates[k].position.x = x;
                                            grid_updates[k].position.y = y;
                                            k++;
                                        }
                                    }
                                }

                                smp server_msg = {player_pids[i], &result};
                                print_output(NULL, &server_msg, grid_updates, filled_count); // Log valid move
    
                                // Check for winner
                                int directions[4][2] = {{1, 0}, {0, 1}, {1, 1}, {1, -1}};
                                for (int d = 0; d < 4; d++) {
                                    int count = 1;
                                    for (int j = 1; j < streak_size; j++) {
                                        int nx = msg.position.x + j * directions[d][0];
                                        int ny = msg.position.y + j * directions[d][1];
                                        if (nx >= 0 && nx < grid_width && ny >= 0 && ny < grid_height &&
                                            grid[ny][nx] == player_symbols[i]) {
                                            count++;
                                        } else break;
                                    }
                                    for (int j = 1; j < streak_size; j++) {
                                        int nx = msg.position.x - j * directions[d][0];
                                        int ny = msg.position.y - j * directions[d][1];
                                        if (nx >= 0 && nx < grid_width && ny >= 0 && ny < grid_height &&
                                            grid[ny][nx] == player_symbols[i]) {
                                            count++;
                                        } else break;
                                    }
                                    if (count >= streak_size) {
                                        winner_detected = 1;
                                        break;
                                    }
                                }
    
                                // Check for draw
                                is_grid_full = 1;
                                for (int y = 0; y < grid_height && is_grid_full; y++) {
                                    for (int x = 0; x < grid_width; x++) {
                                        if (grid[y][x] == '.') {
                                            is_grid_full = 0;
                                            break;
                                        }
                                    }
                                }
    
                                if (winner_detected || is_grid_full) {
                                    sm end_msg = {END, 0, filled_count};
                                    smp end_log;
                                    gu all_updates[filled_count];
                                    int idx = 0;
                                    for (int y = 0; y < grid_height; y++) {
                                        for (int x = 0; x < grid_width; x++) {
                                            if (grid[y][x] != '.') {
                                                all_updates[idx++] = (gu){{x, y}, grid[y][x]};
                                            }
                                        }
                                    }
    
                                    for (int p = 0; p < player_count; p++) {
                                        write(pipes[p][1], &end_msg, sizeof(end_msg));
                                        end_log.process_id = player_pids[p];
                                        end_log.server_message = &end_msg;
                                        print_output(NULL, &end_log, NULL, 0);
                                    }
    
                                    if (winner_detected) {
                                        printf("Winner: Player%c\n", player_symbols[i]);
                                    } else {
                                        printf("Draw\n");
                                    }
                                }
                            } else {
                                sm result = {RESULT, 0, filled_count};
                                write(pipes[i][1], &result, sizeof(result));
                                smp server_msg = {player_pids[i], &result};
                                print_output(NULL, &server_msg, NULL, filled_count); // Log invalid move
                            }
                        }
                    } else {
                        perror("Error while reading from the pipe");
                        return -1;
                    }
                }
            }
        }
    }

    // Close all pipes and free memory
    for (int i = 0; i < player_count; i++) {
        close(pipes[i][1]);
        int child_status;
        waitpid(player_pids[i], &child_status, 0);
        for (int j = 0; j <= player_arg_count[i]; j++) {
            free(player_args[i][j]);
        }
        free(player_args[i]);
        free(pipes[i]);
    }

    // Free grid memory
    for (int i = 0; i < grid_height; i++) {
        free(grid[i]);
    }
    free(grid);

    // Free other memory allocations
    free(player_pids);
    free(player_symbols);
    free(player_arg_count);
    free(player_args);
    free(pipes);

    return 0;
}

