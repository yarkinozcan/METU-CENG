#include "ext2fs.h"
#include "ext2fs_print.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/stat.h>

#define S_IFMT  0170000  
#define S_IFDIR 0040000  
#define S_ISDIR(m) (((m) & S_IFMT) == S_IFDIR)

int file_fd;
struct ext2_super_block sb;
struct ext2_block_group_descriptor *bg_desc;
uint32_t blk_size;
uint32_t total_groups;

struct file_operation {
    uint32_t time_stamp;
    char command[16];
    char from_path[512];
    char to_path[512];
    uint32_t changed_dirs[4];
    int dir_count;
    uint32_t changed_inodes[4];
    int inode_count;
    int confidence_level; 
};

struct deleted_entry {
    uint32_t inode_num;
    char entry_name[EXT2_MAX_NAME_LENGTH + 1];
    char complete_path[512];
    uint32_t parent_dir;
    int is_dir;
};

struct node_data {
    uint32_t node_number;
    uint32_t parent_node;
    char node_name[EXT2_MAX_NAME_LENGTH + 1];
    char complete_path[512];
    int is_dir;
    int deleted;
    struct ext2_inode node_info;
};

struct file_operation operations[1000];
int op_count = 0;
struct deleted_entry deleted_stuff[500];
int deleted_count = 0;
struct node_data node_list[1000];
int node_count = 0;

// Forward declarations
void show_directory_tree(FILE *output, uint32_t node_num, int level, char *path);
void show_directory_contents(FILE *output, uint32_t dir_node, int level, char *path);
void traverse_deleted_directory(uint32_t dir_node, char *path);
void process_directory_block(FILE *output, uint32_t block_num, uint32_t dir_node, int level, char *path, int print_output);
void process_indirect_blocks(FILE *output, uint32_t indirect_block, uint32_t dir_node, int level, char *path, int print_output);
void process_double_indirect_blocks(FILE *output, uint32_t double_indirect, uint32_t dir_node, int level, char *path, int print_output);
void process_triple_indirect_blocks(FILE *output, uint32_t triple_indirect, uint32_t dir_node, int level, char *path, int print_output);

int get_superblock() {
    lseek(file_fd, EXT2_SUPER_BLOCK_POSITION, SEEK_SET);
    read(file_fd, &sb, sizeof(struct ext2_super_block));
    
    blk_size = EXT2_UNLOG(sb.log_block_size);
    total_groups = (sb.block_count + sb.blocks_per_group - 1) / sb.blocks_per_group;

    //printf("%d %d", blk_size, total_groups);
    
    return 0;
}

int get_group_descriptors() {
    uint32_t descriptor_offset;
    if (blk_size == 1024) {
        descriptor_offset = 2048; 
    } else {
        descriptor_offset = blk_size; 
    }

    bg_desc = malloc(total_groups * sizeof(struct ext2_block_group_descriptor));
    lseek(file_fd, descriptor_offset, SEEK_SET);
    read(file_fd, bg_desc, total_groups * sizeof(struct ext2_block_group_descriptor));

    return 0;
}

int get_inode(uint32_t node_num, struct ext2_inode *node) {
    uint32_t node_index = node_num - 1;
    uint32_t group_index = node_index / sb.inodes_per_group;
    uint32_t local_node_index = node_index % sb.inodes_per_group;

    uint32_t inode_table_blk = bg_desc[group_index].inode_table;
    uint32_t node_offset = inode_table_blk * blk_size + local_node_index * sb.inode_size;

    lseek(file_fd, node_offset, SEEK_SET);
    read(file_fd, node, sizeof(struct ext2_inode));

    return 0;
}

int get_block(uint32_t block_num, void *buffer) {
    uint64_t position = (uint64_t)block_num * blk_size;
    lseek(file_fd, position, SEEK_SET);
    read(file_fd, buffer, blk_size);
    return 0;
}

struct node_data* lookup_node_info(uint32_t node_num) {
    int i;
    for (i = 0; i < node_count; i++) {
        if (node_list[i].node_number == node_num) {
            return &node_list[i];
        }
    }
    return NULL;
}

void store_node_info(uint32_t node_num, uint32_t parent_num, const char *name, const char *path, int directory) {
    struct node_data *info = lookup_node_info(node_num);
    if (info) {
        info->parent_node = parent_num;
        strncpy(info->node_name, name, EXT2_MAX_NAME_LENGTH);
        info->node_name[EXT2_MAX_NAME_LENGTH] = '\0';
        strncpy(info->complete_path, path, 511);
        info->complete_path[511] = '\0';
    }
}

void make_node_map() {
    int i;
    for (i = 1; i <= sb.inode_count; i++) {
        struct ext2_inode node;
        get_inode(i, &node);
        
        if (node.mode != 0) {
            if (node_count < 1000) {
                node_list[node_count].node_number = i;
                node_list[node_count].node_info = node;
                node_list[node_count].deleted = (node.deletion_time != 0);
                node_list[node_count].is_dir = S_ISDIR(node.mode);
                strcpy(node_list[node_count].node_name, "");
                strcpy(node_list[node_count].complete_path, "");
                node_list[node_count].parent_node = 0;
                node_count++;
            }
        }
    }
}

int check_valid_name(const char *name, uint8_t len) {
    if (len == 0) return 0;
    if (len == 1 && name[0] == '.') return 0;  
    if (len == 2 && name[0] == '.' && name[1] == '.') return 0;  
    
    // check printable characters
    int i;
    for (i = 0; i < len; i++) {
        if (name[i] < 32 || name[i] > 126) {
            return 0;
        }
    }
    return 1;
}

void process_directory_block(FILE *output, uint32_t block_num, uint32_t dir_node, int level, char *path, int print_output) {
    if (block_num == 0) return;

    void *block_data = malloc(blk_size);
    get_block(block_num, block_data);

    uint32_t pos = 0;
    while (pos < blk_size) {
        struct ext2_dir_entry *entry = (struct ext2_dir_entry *)((char *)block_data + pos);
        
        if (entry->inode != 0 && check_valid_name(entry->name, entry->name_length)) {
            char name[EXT2_MAX_NAME_LENGTH + 1];
            strncpy(name, entry->name, entry->name_length);
            name[entry->name_length] = '\0';

            char new_path[1024];
            if (strcmp(path, "/") == 0) {
                snprintf(new_path, sizeof(new_path), "/%s", name);
            } else {
                snprintf(new_path, sizeof(new_path), "%s/%s", path, name);
            }

            struct ext2_inode child;
            get_inode(entry->inode, &child);
            store_node_info(entry->inode, dir_node, name, new_path, 
                         ((child.mode & 0xF000) == EXT2_I_DTYPE));

            if (print_output) {
                show_directory_tree(output, entry->inode, level, new_path);
            } else {
                if (deleted_count < 500) {
                    deleted_stuff[deleted_count].inode_num = entry->inode;
                    strcpy(deleted_stuff[deleted_count].entry_name, name);
                    deleted_stuff[deleted_count].parent_dir = dir_node;
                    deleted_stuff[deleted_count].is_dir = ((child.mode & 0xF000) == EXT2_I_DTYPE);
                    strcpy(deleted_stuff[deleted_count].complete_path, new_path);
                    deleted_count++;
                }

                if ((child.mode & 0xF000) == EXT2_I_DTYPE) {
                    traverse_deleted_directory(entry->inode, new_path);
                }
            }
        }

        uint32_t real_entry_size = 8 + ((entry->name_length + 3) & ~3);
        uint32_t leftover_space = entry->length - real_entry_size;
        
        if (leftover_space >= 8) {
            uint32_t ghost_pos = pos + real_entry_size;
            
            while (ghost_pos + 8 <= pos + entry->length) {
                struct ext2_dir_entry *ghost = (struct ext2_dir_entry *)((char *)block_data + ghost_pos);
                
                if (ghost->inode != 0 && 
                    ghost->name_length > 0 && 
                    ghost->name_length <= EXT2_MAX_NAME_LENGTH &&
                    ghost_pos + 8 + ghost->name_length <= pos + entry->length &&
                    check_valid_name(ghost->name, ghost->name_length)) {
                    
                    char ghost_name[EXT2_MAX_NAME_LENGTH + 1];
                    strncpy(ghost_name, ghost->name, ghost->name_length);
                    ghost_name[ghost->name_length] = '\0';
                    
                    if (print_output) {
                        int j;
                        for (j = 0; j < level; j++) {
                            fprintf(output, "-");
                        }
                        
                        struct ext2_inode ghost_node;
                        get_inode(ghost->inode, &ghost_node);
                        fprintf(output, " (%u:%s", ghost->inode, ghost_name);
                        if ((ghost_node.mode & 0xF000) == EXT2_I_DTYPE) {
                            fprintf(output, "/");
                        }
                        fprintf(output, ")\n");
                    }

                    if (deleted_count < 500) {
                        deleted_stuff[deleted_count].inode_num = ghost->inode;
                        strcpy(deleted_stuff[deleted_count].entry_name, ghost_name);
                        deleted_stuff[deleted_count].parent_dir = dir_node;
                        
                        struct ext2_inode ghost_node;
                        get_inode(ghost->inode, &ghost_node);
                        deleted_stuff[deleted_count].is_dir = ((ghost_node.mode & 0xF000) == EXT2_I_DTYPE);
                        
                        if (strcmp(path, "/") == 0) {
                            snprintf(deleted_stuff[deleted_count].complete_path, 512, "/%s", ghost_name);
                        } else {
                            snprintf(deleted_stuff[deleted_count].complete_path, 512, "%s/%s", path, ghost_name);
                        }
                        
                        deleted_count++;

                        if ((ghost_node.mode & 0xF000) == EXT2_I_DTYPE) {
                            traverse_deleted_directory(ghost->inode, deleted_stuff[deleted_count-1].complete_path);
                        }
                    }
                    
                    ghost_pos += 8 + ((ghost->name_length + 3) & ~3);
                } else {
                    ghost_pos += 4;
                }
            }
        }
        
        pos += entry->length;
    }

    free(block_data);
}

void process_indirect_blocks(FILE *output, uint32_t indirect_block, uint32_t dir_node, int level, char *path, int print_output) {
    if (indirect_block == 0) return;

    uint32_t *block_ptrs = malloc(blk_size);
    get_block(indirect_block, block_ptrs);

    for (uint32_t i = 0; i < blk_size/4; i++) {
        if (block_ptrs[i] == 0) break;
        process_directory_block(output, block_ptrs[i], dir_node, level, path, print_output);
    }

    free(block_ptrs);
}

void process_double_indirect_blocks(FILE *output, uint32_t double_indirect, uint32_t dir_node, int level, char *path, int print_output) {
    if (double_indirect == 0) return;

    uint32_t *indirect_blocks = malloc(blk_size);
    get_block(double_indirect, indirect_blocks);

    for (uint32_t i = 0; i < blk_size/4; i++) {
        if (indirect_blocks[i] == 0) break;
        process_indirect_blocks(output, indirect_blocks[i], dir_node, level, path, print_output);
    }

    free(indirect_blocks);
}

void process_triple_indirect_blocks(FILE *output, uint32_t triple_indirect, uint32_t dir_node, int level, char *path, int print_output) {
    if (triple_indirect == 0) return;

    uint32_t *double_blocks = malloc(blk_size);
    get_block(triple_indirect, double_blocks);

    for (uint32_t i = 0; i < blk_size/4; i++) {
        if (double_blocks[i] == 0) break;
        process_double_indirect_blocks(output, double_blocks[i], dir_node, level, path, print_output);
    }

    free(double_blocks);
}

void show_directory_contents(FILE *output, uint32_t dir_node, int level, char *path) {
    struct ext2_inode directory;
    get_inode(dir_node, &directory);

    for (int i = 0; i < EXT2_NUM_DIRECT_BLOCKS; i++) {
        if (directory.direct_blocks[i] == 0) break;
        process_directory_block(output, directory.direct_blocks[i], dir_node, level, path, 1);
    }

    process_indirect_blocks(output, directory.single_indirect, dir_node, level, path, 1);
    process_double_indirect_blocks(output, directory.double_indirect, dir_node, level, path, 1);
    process_triple_indirect_blocks(output, directory.triple_indirect, dir_node, level, path, 1);
}

void traverse_deleted_directory(uint32_t dir_node, char *path) {
    struct ext2_inode directory;
    get_inode(dir_node, &directory);

    for (int i = 0; i < EXT2_NUM_DIRECT_BLOCKS; i++) {
        if (directory.direct_blocks[i] == 0) break;
        process_directory_block(NULL, directory.direct_blocks[i], dir_node, 0, path, 0);
    }

    process_indirect_blocks(NULL, directory.single_indirect, dir_node, 0, path, 0);
    process_double_indirect_blocks(NULL, directory.double_indirect, dir_node, 0, path, 0);
    process_triple_indirect_blocks(NULL, directory.triple_indirect, dir_node, 0, path, 0);
}

void show_directory_tree(FILE *output, uint32_t node_num, int level, char *path) {
    struct ext2_inode node;
    get_inode(node_num, &node);

    int i;
    for (i = 0; i < level; i++) {
        fprintf(output, "-");
    }
    
    char *dir_name = strrchr(path, '/');
    if (dir_name) {
        dir_name++; 
    } else {
        dir_name = path;
    }
    
    if (node_num == EXT2_ROOT_INODE) {
        fprintf(output, " %u:root/\n", node_num);
        store_node_info(node_num, 0, "root", "/", 1);
    } else {
        fprintf(output, " %u:%s", node_num, dir_name);
        if ((node.mode & 0xF000) == EXT2_I_DTYPE) {
            fprintf(output, "/");
        }
        fprintf(output, "\n");
    }

    if ((node.mode & 0xF000) == EXT2_I_DTYPE) {
        show_directory_contents(output, node_num, level + 1, path);
    }
}

int sort_operations(const void *a, const void *b) {
    const struct file_operation *op1 = (const struct file_operation *)a;
    const struct file_operation *op2 = (const struct file_operation *)b;
    
    if (op1->time_stamp == 0 && op2->time_stamp == 0) return 0;
    if (op1->time_stamp == 0) return 1;
    if (op2->time_stamp == 0) return -1;
    
    if (op1->time_stamp < op2->time_stamp) return -1;
    if (op1->time_stamp > op2->time_stamp) return 1;
    return 0;
}

void create_path_from_node(uint32_t node_num, char *path, int max_length) {
    struct node_data *info = lookup_node_info(node_num);
    if (info && strlen(info->complete_path) > 0) {
        strncpy(path, info->complete_path, max_length - 1);
        path[max_length - 1] = '\0';
    } else {
        strcpy(path, "?");
    }
}

void write_history(FILE *history_output) {
    int i;
    for (i = 0; i < op_count; i++) {
        struct file_operation *op = &operations[i];
        
        int filled = 0;
        if (op->time_stamp != 0) filled++;
        if (strlen(op->command) > 0) filled++;
        if (strlen(op->from_path) > 0 && strcmp(op->from_path, "?") != 0) filled++;
        if (strlen(op->to_path) > 0 && strcmp(op->to_path, "?") != 0) filled++;
        if (op->dir_count > 0) filled++;
        if (op->inode_count > 0) filled++;
        
        if (filled < 2) continue;
        
        if (op->time_stamp != 0) {
            fprintf(history_output, "%u", op->time_stamp);
        } else {
            fprintf(history_output, "?");
        }
        
        fprintf(history_output, " %s", op->command);
        
        fprintf(history_output, " [%s", op->from_path);
        if (strlen(op->to_path) > 0) {
            fprintf(history_output, " %s", op->to_path);
        }
        fprintf(history_output, "]");
        
        fprintf(history_output, " [");
        if (op->dir_count > 0) {
            int j;
            for (j = 0; j < op->dir_count; j++) {
                if (j > 0) fprintf(history_output, " ");
                fprintf(history_output, "%u", op->changed_dirs[j]);
            }
        } else {
            fprintf(history_output, "?");
        }
        fprintf(history_output, "]");
        
        fprintf(history_output, " [");
        if (op->inode_count > 0) {
            int j;
            for (j = 0; j < op->inode_count; j++) {
                if (j > 0) fprintf(history_output, " ");
                fprintf(history_output, "%u", op->changed_inodes[j]);
            }
        } else {
            fprintf(history_output, "?");
        }
        fprintf(history_output, "]\n");
    }
}

void rebuild_operations() {
    int i;
    for (i = 0; i < node_count; i++) {
        struct node_data *info = &node_list[i];

        if (info->node_number <= 10 || info->node_info.access_time == 0) continue;

        struct file_operation *op = &operations[op_count];

        if (info->is_dir) {
            strcpy(op->command, "mkdir");
        } else {
            strcpy(op->command, "touch");
        }

        op->time_stamp = info->node_info.access_time;

        int deleted_entries = 0;
        for (int j = 0; j < deleted_count; j++) {
            if (deleted_stuff[j].inode_num == info->node_number) {
                deleted_entries++;
            }
        }

        if (deleted_entries > 1) {
            int match_count = 0;
            int match_index = -1;

            for (int j = 0; j < deleted_count; j++) {
                if (deleted_stuff[j].inode_num == info->node_number) {
                    struct node_data *parent_info = lookup_node_info(deleted_stuff[j].parent_dir);
                    if (parent_info && parent_info->node_info.access_time < info->node_info.access_time) {
                        match_count++;
                        match_index = j;
                    }
                }
            }

            if (match_count == 1) {
                strcpy(op->from_path, deleted_stuff[match_index].complete_path);
                op->changed_dirs[0] = deleted_stuff[match_index].parent_dir;
                op->dir_count = 1;
            } else {
                strcpy(op->from_path, "?");
                op->dir_count = 0;
            }

        } else if (deleted_entries == 1) {
            for (int j = 0; j < deleted_count; j++) {
                if (deleted_stuff[j].inode_num == info->node_number) {
                    strcpy(op->from_path, deleted_stuff[j].complete_path);
                    op->changed_dirs[0] = deleted_stuff[j].parent_dir;
                    op->dir_count = 1;
                    break;
                }
            }

        } else {
            if (strlen(info->complete_path) > 0) {
                strcpy(op->from_path, info->complete_path);
            } else {
                strcpy(op->from_path, "?");
            }

            if (info->parent_node != 0) {
                op->changed_dirs[0] = info->parent_node;
                op->dir_count = 1;
            } else {
                op->dir_count = 0;
            }
        }

        strcpy(op->to_path, "");
        op->changed_inodes[0] = info->node_number;
        op->inode_count = 1;

        op_count++;
    }
    
    for (i = 0; i < node_count; i++) {
        struct node_data *info = &node_list[i];
        if (info->deleted && info->node_info.deletion_time != 0) {
            struct file_operation *op = &operations[op_count];
            op->time_stamp = info->node_info.deletion_time;
            
            if (info->is_dir) {
                strcpy(op->command, "rmdir");
            } else {
                strcpy(op->command, "rm");
            }
            
            int found = 0;
            int j;
            for (j = 0; j < deleted_count; j++) {
                if (deleted_stuff[j].inode_num == info->node_number) {
                    strcpy(op->from_path, deleted_stuff[j].complete_path);
                    op->changed_dirs[0] = deleted_stuff[j].parent_dir;
                    op->dir_count = 1;
                    found = 1;
                    break;
                }
            }
            
            if (!found) {
                strcpy(op->from_path, "?");
                op->changed_dirs[0] = 0;
                op->dir_count = 0;
            }
            
            strcpy(op->to_path, "");
            op->changed_inodes[0] = info->node_number;
            op->inode_count = 1;
            
            op_count++;
        }
    }
    
    typedef struct {
        int count;
        int indices[10]; 
    } ghost_group;

    ghost_group ghost_map[10000] = {0};

    for (int i = 0; i < deleted_count; i++) {
        int id = deleted_stuff[i].inode_num;
        ghost_map[id].indices[ghost_map[id].count++] = i;
    }

    for (int inode = 1; inode < 10000; inode++) {
        if (ghost_map[inode].count == 0) continue;

        struct node_data *info = lookup_node_info(inode);
        if (!info) continue;

        int count = ghost_map[inode].count;

        if (info->deleted && count == 1) continue;

        for (int a = 0; a < count - 1; a++) {
            for (int b = a + 1; b < count; b++) {
                uint32_t time_a = 0, time_b = 0;
                struct node_data *p_a = lookup_node_info(deleted_stuff[ghost_map[inode].indices[a]].parent_dir);
                struct node_data *p_b = lookup_node_info(deleted_stuff[ghost_map[inode].indices[b]].parent_dir);
                if (p_a) time_a = p_a->node_info.access_time;
                if (p_b) time_b = p_b->node_info.access_time;

                if (time_a > time_b) {
                    int tmp = ghost_map[inode].indices[a];
                    ghost_map[inode].indices[a] = ghost_map[inode].indices[b];
                    ghost_map[inode].indices[b] = tmp;
                }
            }
        }

        for (int g = 0; g < count; g++) {
            int idx = ghost_map[inode].indices[g];
            struct deleted_entry *from = &deleted_stuff[idx];
            struct file_operation *op = &operations[op_count++];
            strcpy(op->command, "mv");

            strcpy(op->from_path, from->complete_path);
            op->changed_dirs[0] = from->parent_dir;
            op->dir_count = 1;
            op->changed_inodes[0] = inode;
            op->inode_count = 1;

            if (g == count - 1) {
                if (!info->deleted && strlen(info->complete_path) > 0) {
                    strcpy(op->to_path, info->complete_path);
                    op->time_stamp = info->node_info.change_time;
                    if (info->parent_node != from->parent_dir) {
                        op->changed_dirs[1] = info->parent_node;
                        op->dir_count = 2;
                    }
                } else {
                    strcpy(op->to_path, "?");
                    op->time_stamp = 0;
                }
            } else {
                int next_idx = ghost_map[inode].indices[g + 1];
                struct deleted_entry *to = &deleted_stuff[next_idx];
                strcpy(op->to_path, to->complete_path);
                op->time_stamp = 0; 
                op->changed_dirs[1] = to->parent_dir;
                op->dir_count = 2;
            }
        }
    }
}

void examine_filesystem_history(FILE *history_output) {
    rebuild_operations();
    
    qsort(operations, op_count, sizeof(struct file_operation), sort_operations);
    
    write_history(history_output);
}

int main(int argc, char *argv[]) {
    char *img_path = argv[1];
    char *state_file = argv[2];
    char *history_file = argv[3];

    file_fd = open(img_path, O_RDONLY);

    get_superblock();

    get_group_descriptors();

    make_node_map();

    FILE *state_output = fopen(state_file, "w");

    char root[2] = "/";
    show_directory_tree(state_output, EXT2_ROOT_INODE, 1, root);
    fclose(state_output);

    FILE *history_output = fopen(history_file, "w");

    examine_filesystem_history(history_output);
    fclose(history_output);

    close(file_fd);
    free(bg_desc);

    return 0;
}